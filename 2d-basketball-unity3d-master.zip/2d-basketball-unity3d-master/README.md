# 2D Ball Shootout Unity3d [Source Code]

If you have any questions -> http://twitter.com/skakac
<br /><br />
https://play.google.com/store/apps/details?id=com.skakac.bshootout<br />
Ball Shootout game <br />
Super simple basketball game, using popular idea with some changes.<br />
You can try out 2 player multiplayer mode, and compete on global leaderboard.<br />

<br />
How to play:<br />
1. Touch the screen.<br />
2. Drag to change predicted path.<br />
3. Release. <br />
4. You can always drag and release behind the basket to release without shooting the ball. <br />
5. In options menu you can change shoot power. <br />
Follow on twitter: http://twitter.com/skakac<br />

